
          
        <?php 
          
        ?>
        <!-- JAVASCRIPT -->
        
        <script src="<?=base_url('public/assets/libs/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/metismenu/metisMenu.min.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/simplebar/simplebar.min.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/node-waves/waves.min.js'); ?>"></script>
      
        <!-- Responsive examples -->
  
        <script src="<?=base_url('public/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js'); ?>"></script>
        <script src="<?=base_url('public/assets/js/app.js'); ?>"></script>
        <script src="<?=base_url('public/assets/js/logout.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/sweetalert2/sweetalert2.min.js'); ?>"></script>
       
     
        <script src="<?=base_url('public/assets/libs/jquery-confirm/js/jquery-confirm.js'); ?>"></script>
       
          <script src="<?=base_url('public/assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js'); ?>"></script>

        <script src="<?=base_url('public/assets/libs/twitter-bootstrap-wizard/prettify.js'); ?>"></script>
        <script src="<?=base_url('public/assets/js/pages/form-wizard.init.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/select2/js/select2.min.js'); ?>"></script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
	
       
    
    
           
