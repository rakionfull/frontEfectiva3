
            <!-- End Page-content -->
        <!-- <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <script>document.write(new Date().getFullYear())</script> © Valtx.
                    </div>
                    <div class="col-sm-6">
                        <div class="text-sm-right d-none d-sm-block">
                           Desarrollado por Valtx
                        </div>
                    </div>
                </div>
            </div>
        </footer> -->

        <?php 
          
        ?>
        <!-- JAVASCRIPT -->
        
        <script src="<?=base_url('public/assets/libs/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/metismenu/metisMenu.min.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/simplebar/simplebar.min.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/node-waves/waves.min.js'); ?>"></script>
      
        <!-- Responsive examples -->
  
        <script src="<?=base_url('public/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js'); ?>"></script>
        <script src="<?=base_url('public/assets/js/app.js'); ?>"></script>
        <script src="<?=base_url('public/assets/js/logout.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/sweetalert2/sweetalert2.min.js'); ?>"></script>
       
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
          <!-- twitter-bootstrap-wizard js -->
          <script src="<?=base_url('public/assets/libs/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js'); ?>"></script>

        <script src="<?=base_url('public/assets/libs/twitter-bootstrap-wizard/prettify.js'); ?>"></script>
        <script src="<?=base_url('public/assets/js/pages/form-wizard.init.js'); ?>"></script>
        <script src="<?=base_url('public/assets/libs/select2/js/select2.min.js'); ?>"></script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
		<!-- <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> -->

       
    
    
           
